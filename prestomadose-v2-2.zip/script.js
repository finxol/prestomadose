(() => {
    let script = document.createElement('script');
    script.src = "https://cdn.jsdelivr.net/gh/user038418/prestomadose@v2.2/dose_covid.js";
    document.body.appendChild(script);
})();